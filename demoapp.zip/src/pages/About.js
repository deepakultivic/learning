import React from 'react';

function About(){
    return(
        <>about works !</>
    );
}
export default About;