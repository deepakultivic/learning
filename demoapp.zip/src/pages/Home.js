import react from 'react';
import Header from '../components/Header'
function Home(){
    return(
        <>
    <Header></Header>
        </>
    );
}
export default Home;